# v0.0.2

* Install package by name, as long as it's unique on the App Store.
* Saner handling of versions.
* Fixed some showstopper bugs.

# v0.0.1

* Initial barely functional release.
